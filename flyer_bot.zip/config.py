BOT_TOKEN = "8500994183:AAFuJAtatem_2olCueCceAPi9QxMOL08_EE"
ADMIN_ID = 548858090

DB_CONFIG = {
    "dbname": "SbandStarsdx_necessary",
    "user": "SbandStarsdx_necessary",
    "password": "3e8a6346378acc5eb7ef1e7268f2c54f6a21c1a2",
    "host": "5ikxsp.h.filess.io"
}

FLYER_API_KEY = "FL-eliuMo-kzwWnO-uvimwU-UOfqjW"
FLYER_BASE_URL = "https://flyerapi.com/api"

TASK_REWARD = 0.25
REF_REWARD = 2.0
MIN_WITHDRAW = 15.0
